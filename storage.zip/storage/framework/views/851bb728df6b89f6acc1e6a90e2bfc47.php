<?php $__env->startSection('title', 'Team Performance - Manager Dashboard'); ?>
<?php $__env->startSection('page-title', 'Team Performance'); ?>
<?php $__env->startSection('page-icon', 'bi bi-graph-up'); ?>
<?php $__env->startSection('page-description', 'Monitor and evaluate team performance'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5><i class="bi bi-graph-up"></i> Team Performance</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Employee</th>
                                    <th>Score</th>
                                    <th>Completed Tasks</th>
                                    <th>On-Time Rate</th>
                                    <th>Rating</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $performanceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $performance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($performance['employee']); ?></td>
                                    <td>
                                        <div class="progress" style="height: 20px;">
                                            <div class="progress-bar" role="progressbar" style="width: <?php echo e($performance['score']); ?>%">
                                                <?php echo e($performance['score']); ?>%
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($performance['completed_tasks']); ?></td>
                                    <td><?php echo e($performance['on_time_rate']); ?>%</td>
                                    <td>
                                        <span class="badge bg-primary"><?php echo e($performance['rating']); ?></span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-primary">
                                            <i class="bi bi-eye"></i> Details
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No performance data available</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\imteaz\HR-Management\resources\views/manager/performance.blade.php ENDPATH**/ ?>