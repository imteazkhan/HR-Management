<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Employee Management - Super Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { 
            background: #f8f9fa; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar { 
            background: #2c3e50; 
            min-height: 100vh; 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 250px; 
            z-index: 1000;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link { 
            color: #ecf0f1; 
            padding: 12px 20px; 
            transition: all 0.3s ease;
            border-radius: 8px;
            margin: 2px 8px;
        }
        .sidebar .nav-link:hover { 
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: #fff;
            transform: translateX(5px);
        }
        .sidebar .nav-link.active { 
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: #fff;
        }
        .sidebar .nav-link i { 
            width: 20px; 
            margin-right: 10px;
        }
        .sidebar .dropdown-menu {
            background: #34495e;
            border: none;
            border-radius: 8px;
            padding: 0.5rem 0;
            margin: 0.5rem 0 0 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .sidebar .dropdown-item {
            color: #ecf0f1;
            padding: 0.5rem 1.5rem;
            transition: all 0.3s ease;
        }
        .sidebar .dropdown-item:hover {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: #fff;
        }
        .sidebar .dropdown-toggle::after {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
        }
        .main-content { 
            margin-left: 250px; 
            padding: 20px;
            transition: all 0.3s ease;
        }
        .mobile-header {
            display: none;
            background: #2c3e50;
            color: white;
            padding: 15px;
            position: sticky;
            top: 0;
            z-index: 999;
        }
        .mobile-toggle {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
        }
        .card { 
            border: none; 
            border-radius: 15px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.08); 
            /* transition: all 0.3s ease; */
            margin-bottom: 20px;
            overflow: hidden;
        }
        .card:hover { 
           transform: translateY(-1px);
            box-shadow: 0 12px 40px rgba(0,0,0,0.15);
        }
        .stat-card { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white;
        }
        .stat-card-2 { 
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); 
            color: white;
        }
        .stat-card-3 { 
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); 
            color: white;
        }
        .stat-card-4 { 
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); 
            color: white;
        }
        .navbar-brand { 
            font-weight: 700; 
            font-size: 1.5rem; 
            color: #fff !important;
        }
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        
        /* Button Animations */
        .btn {
            /* transition: all 0.3s ease; */
            border-radius: 8px;
        }
        .btn:hover {
            /* transform: translateY(-2px); */
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        .btn:active {
            transform: translateY(0);
        }
        
        /* Progress Bars */
        .progress {
            height: 8px;
            border-radius: 4px;
            overflow: hidden;
        }
        .progress-bar {
            transition: width 1s ease-in-out;
        }
        
        /* Employee specific styles */
        .avatar-circle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .id-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border: 1px solid #e0e0e0;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .id-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #3498db, #2980b9, #e74c3c, #c0392b);
        }
        .qr-code-container {
            background: white;
            padding: 10px;
            border-radius: 10px;
            margin: 15px auto;
            width: fit-content;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .employee-info {
            text-align: left;
            margin-top: 15px;
        }
        .employee-info p {
            margin: 5px 0;
            font-size: 0.9rem;
        }
        .employee-name {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 5px;
            color: #2c3e50;
        }
        .employee-role {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        .company-header {
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: white;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        .company-header h5 {
            margin: 0;
            font-size: 1.1rem;
        }
        
        .table-row-hover:hover {
            background-color: rgba(52, 152, 219, 0.1);
            /* transform: scale(1.01); */
            transition: all 0.2s ease;
        }
        
        /* Mobile Responsive */
        @media (max-width: 991.98px) {
            .sidebar { 
                transform: translateX(-100%); 
                transition: transform 0.3s ease;
            }
            .sidebar.show { 
                transform: translateX(0);
            }
            .main-content { 
                margin-left: 0;
                padding: 15px;
            }
            .mobile-header {
                display: flex;
                justify-content: between;
                align-items: center;
            }
            .sidebar-overlay.show {
                display: block;
            }
        }
        
        @media (max-width: 767.98px) {
            .stat-card h2 {
                font-size: 1.5rem;
            }
            .card-body {
                padding: 1rem;
            }
            .col-lg-3 {
                margin-bottom: 15px;
            }
        }
        
        @media (max-width: 575.98px) {
            .main-content {
                padding: 10px;
            }
            .card {
                margin-bottom: 15px;
            }
            .stat-card h6 {
                font-size: 0.8rem;
            }
            .stat-card h2 {
                font-size: 1.2rem;
            }
            .btn {
                font-size: 0.8rem;
                padding: 0.4rem 0.8rem;
            }
        }
        
        /* Animations */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        .pulse-animation {
            animation: pulse 2s infinite;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }
        
        /* Modal styles */
        .modal-content {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .modal-header {
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: white;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
        
        /* Alert styles */
        .alert {
            border-radius: 10px;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <!-- Mobile Header -->
    <div class="mobile-header d-lg-none">
        <button class="mobile-toggle" id="sidebarToggle">
            <i class="bi bi-list"></i>
        </button>
        <div class="ms-2">
            <span class="fw-bold">Super Admin</span>
        </div>
        <div class="ms-auto">
            <button class="btn btn-sm btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="bi bi-person-circle"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#"><i class="bi bi-person"></i> Profile</a></li>
                <li><a class="dropdown-item" href="#"><i class="bi bi-gear"></i> Settings</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?php echo e(route('logout.confirm')); ?>"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
            </ul>
        </div>
    </div>
    
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    
    <!-- Sidebar -->
    <nav class="sidebar" id="sidebar">
        <div class="p-3">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <i class="bi bi-briefcase"></i> iK soft
            </a>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.dashboard')); ?>"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.employees') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.employees')); ?>"><i class="bi bi-people"></i> Employees</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.designations') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.designations')); ?>"><i class="bi bi-award"></i> Designations</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.departments') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.departments')); ?>"><i class="bi bi-building"></i> Departments</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.user-roles') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.user-roles')); ?>"><i class="bi bi-person-badge"></i> User Roles</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.payroll') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.payroll')); ?>"><i class="bi bi-cash-stack"></i> Payroll Management</a></li>

                        <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.attendance.index') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.attendance.index')); ?>"><i class="bi bi-calendar-check"></i> Attendance</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.analytics') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.analytics')); ?>"><i class="bi bi-graph-up"></i> Analytics</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.security') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.security')); ?>"><i class="bi bi-shield-check"></i> System Security</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.settings') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.settings')); ?>"><i class="bi bi-gear"></i> System Settings</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('superadmin.database') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.database')); ?>"><i class="bi bi-database"></i> Database</a></li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 d-none d-lg-flex">
            <h2><i class="bi bi-people-fill text-primary"></i> Employee Management</h2>
            <div class="d-flex align-items-center">
                <span class="me-3 d-none d-md-inline">Welcome, <?php echo e(Auth::user()->name); ?>!</span>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="#"><i class="bi bi-person"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="#"><i class="bi bi-gear"></i> Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('logout.confirm')); ?>"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Mobile Welcome Message -->
        <div class="d-lg-none mb-3">
            <h4 class="mb-1">Welcome back, <?php echo e(Auth::user()->name); ?>!</h4>
            <p class="text-muted mb-0">Employee Management</p>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i><?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <strong>Please fix the following issues:</strong>
                <ul class="mb-0 mt-2">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Employee Tabs -->
        <ul class="nav nav-tabs mb-4" id="employeeTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="all-employees-tab" data-bs-toggle="tab" data-bs-target="#all-employees" type="button" role="tab" aria-controls="all-employees" aria-selected="true">
                    <i class="bi bi-people"></i> All Employees
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="managers-tab" data-bs-toggle="tab" data-bs-target="#managers" type="button" role="tab" aria-controls="managers" aria-selected="false">
                    <i class="bi bi-person-check"></i> Managers
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="staff-tab" data-bs-toggle="tab" data-bs-target="#staff" type="button" role="tab" aria-controls="staff" aria-selected="false">
                    <i class="bi bi-person-workspace"></i> Staff
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="new-employees-tab" data-bs-toggle="tab" data-bs-target="#new-employees" type="button" role="tab" aria-controls="new-employees" aria-selected="false">
                    <i class="bi bi-person-plus"></i> New Employees
                </button>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content" id="employeeTabContent">
            <!-- All Employees Tab -->
            <div class="tab-pane fade show active" id="all-employees" role="tabpanel" aria-labelledby="all-employees-tab">
                <!-- Key Metrics -->
                <div class="row g-3 g-md-4 mb-4">
                    <div class="col-6 col-lg-3">
                        <div class="card stat-card p-3 p-md-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-white-50 mb-1">Total Employees</h6>
                                    <h2><?php echo e($employees->total()); ?></h2>
                                </div>
                                <i class="bi bi-people fs-1 opacity-50 d-none d-md-block"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3">
                        <div class="card stat-card-2 p-3 p-md-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-white-50 mb-1">Managers</h6>
                                    <h2><?php echo e($employees->where('role', 'manager')->count()); ?></h2>
                                </div>
                                <i class="bi bi-person-check fs-1 opacity-50 d-none d-md-block"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3">
                        <div class="card stat-card-3 p-3 p-md-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-white-50 mb-1">Staff</h6>
                                    <h2><?php echo e($employees->where('role', 'employee')->count()); ?></h2>
                                </div>
                                <i class="bi bi-person-workspace fs-1 opacity-50 d-none d-md-block"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3">
                        <div class="card stat-card-4 p-3 p-md-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-white-50 mb-1">New This Month</h6>
                                    <h2><?php echo e($employees->where('created_at', '>=', now()->startOfMonth())->count()); ?></h2>
                                </div>
                                <i class="bi bi-clock-history fs-1 opacity-50 d-none d-md-block"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Employee Actions -->
                <div class="row g-3 g-md-4 mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5><i class="bi bi-person-plus"></i> Employee Management</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex">
                                        <input type="text" class="form-control me-2" placeholder="Search employees..." id="searchEmployees" style="max-width: 300px;">
                                        <button class="btn btn-outline-secondary me-2">
                                            <i class="bi bi-filter"></i> Filter
                                        </button>
                                    </div>
                                    <div>
                                        <a href="<?php echo e(route('superadmin.employees.id-cards')); ?>" class="btn btn-info me-2">
                                            <i class="bi bi-card-heading"></i> ID Cards
                                        </a>
                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                                            <i class="bi bi-person-plus"></i> Add Employee
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Employees Table -->
                <div class="card">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Department</th>
                                        <th>Joined</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="table-row-hover">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle me-3"><?php echo e(substr($employee->name, 0, 1)); ?></div>
                                                <div>
                                                    <h6 class="mb-0"><?php echo e($employee->name); ?></h6>
                                                    <small class="text-muted">ID: #<?php echo e($employee->id); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e($employee->email); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($employee->role === 'manager' ? 'primary' : 'secondary'); ?>">
                                                <?php echo e(ucfirst($employee->role)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if($employee->department): ?>
                                                <span class="text-muted"><?php echo e($employee->department->name); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">No Department</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($employee->created_at->format('M d, Y')); ?></td>
                                        <td>
                                            <span class="badge bg-success">Active</span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="showEmployeeIdCard(<?php echo e($employee->id); ?>, '<?php echo e($employee->name); ?>', '<?php echo e($employee->email); ?>', '<?php echo e($employee->role); ?>', '<?php echo e($employee->created_at->format('M d, Y')); ?>', '<?php echo e($employee->department ? $employee->department->name : 'No Department'); ?>', <?php echo e($employee->department_id ?? 'null'); ?>)" title="View ID Card">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                                <a href="<?php echo e(route('superadmin.employees.edit', $employee)); ?>" class="btn btn-sm btn-outline-secondary" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteEmployee(<?php echo e($employee->id); ?>, '<?php echo e($employee->name); ?>')" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <?php echo e($employees->links()); ?>

                    </div>
                </div>
            </div>

            <!-- Managers Tab -->
            <div class="tab-pane fade" id="managers" role="tabpanel" aria-labelledby="managers-tab">
                <div class="row g-3 g-md-4 mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5><i class="bi bi-person-check"></i> Manager Management</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex">
                                        <input type="text" class="form-control me-2" placeholder="Search managers..." id="searchManagers" style="max-width: 300px;">
                                        <button class="btn btn-outline-secondary me-2">
                                            <i class="bi bi-filter"></i> Filter
                                        </button>
                                    </div>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                                        <i class="bi bi-person-plus"></i> Add Manager
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Department</th>
                                        <th>Team Size</th>
                                        <th>Joined</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees->where('role', 'manager'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="table-row-hover">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle me-3"><?php echo e(substr($manager->name, 0, 1)); ?></div>
                                                <div>
                                                    <h6 class="mb-0"><?php echo e($manager->name); ?></h6>
                                                    <small class="text-muted">ID: #<?php echo e($manager->id); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e($manager->email); ?></td>
                                        <td>
                                            <?php if($manager->department): ?>
                                                <span class="text-muted"><?php echo e($manager->department->name); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">No Department</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-info">5</span>
                                        </td>
                                        <td><?php echo e($manager->created_at->format('M d, Y')); ?></td>
                                        <td>
                                            <span class="badge bg-success">Active</span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="showEmployeeIdCard(<?php echo e($manager->id); ?>, '<?php echo e($manager->name); ?>', '<?php echo e($manager->email); ?>', '<?php echo e($manager->role); ?>', '<?php echo e($manager->created_at->format('M d, Y')); ?>', '<?php echo e($manager->department ? $manager->department->name : 'No Department'); ?>', <?php echo e($manager->department_id ?? 'null'); ?>)" title="View ID Card">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                                <a href="<?php echo e(route('superadmin.employees.edit', $manager)); ?>" class="btn btn-sm btn-outline-secondary" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteEmployee(<?php echo e($manager->id); ?>, '<?php echo e($manager->name); ?>')" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Staff Tab -->
            <div class="tab-pane fade" id="staff" role="tabpanel" aria-labelledby="staff-tab">
                <div class="row g-3 g-md-4 mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5><i class="bi bi-person-workspace"></i> Staff Management</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex">
                                        <input type="text" class="form-control me-2" placeholder="Search staff..." id="searchStaff" style="max-width: 300px;">
                                        <button class="btn btn-outline-secondary me-2">
                                            <i class="bi bi-filter"></i> Filter
                                        </button>
                                    </div>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                                        <i class="bi bi-person-plus"></i> Add Staff
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Department</th>
                                        <th>Position</th>
                                        <th>Joined</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees->where('role', 'employee'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="table-row-hover">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle me-3"><?php echo e(substr($staff->name, 0, 1)); ?></div>
                                                <div>
                                                    <h6 class="mb-0"><?php echo e($staff->name); ?></h6>
                                                    <small class="text-muted">ID: #<?php echo e($staff->id); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e($staff->email); ?></td>
                                        <td>
                                            <?php if($staff->department): ?>
                                                <span class="text-muted"><?php echo e($staff->department->name); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">No Department</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="text-muted">Staff Member</span>
                                        </td>
                                        <td><?php echo e($staff->created_at->format('M d, Y')); ?></td>
                                        <td>
                                            <span class="badge bg-success">Active</span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="showEmployeeIdCard(<?php echo e($staff->id); ?>, '<?php echo e($staff->name); ?>', '<?php echo e($staff->email); ?>', '<?php echo e($staff->role); ?>', '<?php echo e($staff->created_at->format('M d, Y')); ?>', '<?php echo e($staff->department ? $staff->department->name : 'No Department'); ?>', <?php echo e($staff->department_id ?? 'null'); ?>)" title="View ID Card">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                                <a href="<?php echo e(route('superadmin.employees.edit', $staff)); ?>" class="btn btn-sm btn-outline-secondary" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteEmployee(<?php echo e($staff->id); ?>, '<?php echo e($staff->name); ?>')" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- New Employees Tab -->
            <div class="tab-pane fade" id="new-employees" role="tabpanel" aria-labelledby="new-employees-tab">
                <div class="row g-3 g-md-4 mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5><i class="bi bi-person-plus"></i> New Employees (This Month)</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex">
                                        <input type="text" class="form-control me-2" placeholder="Search new employees..." id="searchNewEmployees" style="max-width: 300px;">
                                        <button class="btn btn-outline-secondary me-2">
                                            <i class="bi bi-filter"></i> Filter
                                        </button>
                                    </div>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                                        <i class="bi bi-person-plus"></i> Add Employee
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Department</th>
                                        <th>Joined</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees->where('created_at', '>=', now()->startOfMonth()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newEmployee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="table-row-hover">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle me-3"><?php echo e(substr($newEmployee->name, 0, 1)); ?></div>
                                                <div>
                                                    <h6 class="mb-0"><?php echo e($newEmployee->name); ?></h6>
                                                    <small class="text-muted">ID: #<?php echo e($newEmployee->id); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e($newEmployee->email); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo e($newEmployee->role === 'manager' ? 'primary' : 'secondary'); ?>">
                                                <?php echo e(ucfirst($newEmployee->role)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if($newEmployee->department): ?>
                                                <span class="text-muted"><?php echo e($newEmployee->department->name); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">No Department</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($newEmployee->created_at->format('M d, Y')); ?></td>
                                        <td>
                                            <span class="badge bg-success">Active</span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="showEmployeeIdCard(<?php echo e($newEmployee->id); ?>, '<?php echo e($newEmployee->name); ?>', '<?php echo e($newEmployee->email); ?>', '<?php echo e($newEmployee->role); ?>', '<?php echo e($newEmployee->created_at->format('M d, Y')); ?>', '<?php echo e($newEmployee->department ? $newEmployee->department->name : 'No Department'); ?>', <?php echo e($newEmployee->department_id ?? 'null'); ?>)" title="View ID Card">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                                <a href="<?php echo e(route('superadmin.employees.edit', $newEmployee)); ?>" class="btn btn-sm btn-outline-secondary" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteEmployee(<?php echo e($newEmployee->id); ?>, '<?php echo e($newEmployee->name); ?>')" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Employee Modal -->
    <div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="addEmployeeModalLabel">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addEmployeeModalLabel">Add New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('superadmin.employees.create')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <!-- Personal Information -->
                        <h6 class="text-primary mb-3"><i class="bi bi-person"></i> Personal Information</h6>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="first_name" class="form-label">First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="first_name" name="first_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="last_name" class="form-label">Last Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="last_name" name="last_name" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" id="phone" name="phone">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="date_of_birth" class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" id="date_of_birth" name="date_of_birth">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="gender" class="form-label">Gender</label>
                                <select class="form-select" id="gender" name="gender">
                                    <option value="">Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>

                        <!-- Employment Information -->
                        <h6 class="text-primary mb-3 mt-4"><i class="bi bi-briefcase"></i> Employment Information</h6>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="role" class="form-label">Role <span class="text-danger">*</span></label>
                                <select class="form-select" id="role" name="role" required>
                                    <option value="">Select Role</option>
                                    <option value="employee">Employee</option>
                                    <option value="manager">Manager</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="department_id" class="form-label">Department</label>
                                <select class="form-select" id="department_id" name="department_id">
                                    <option value="">Select Department</option>
                                    <?php $__currentLoopData = $departments ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="joining_date" class="form-label">Joining Date</label>
                                <input type="date" class="form-control" id="joining_date" name="joining_date" value="<?php echo e(now()->format('Y-m-d')); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="employment_type" class="form-label">Employment Type <span class="text-danger">*</span></label>
                                <select class="form-select" id="employment_type" name="employment_type" required>
                                    <option value="">Select Type</option>
                                    <option value="full_time" selected>Full Time</option>
                                    <option value="part_time">Part Time</option>
                                    <option value="contract">Contract</option>
                                    <option value="intern">Intern</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="salary" class="form-label">Salary (BDT)</label>
                                <input type="number" class="form-control" id="salary" name="salary" step="0.01" min="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                                <input type="password" class="form-control" id="password" name="password" required minlength="8">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Employee</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Employee Modal -->
    <div class="modal fade" id="viewEmployeeModal" tabindex="-1" aria-labelledby="viewEmployeeModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewEmployeeModalLabel">Employee Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4 text-center">
                            <div class="avatar-circle mx-auto mb-3" style="width: 80px; height: 80px; font-size: 2em;" id="viewEmployeeAvatar">A</div>
                        </div>
                        <div class="col-md-8">
                            <h4 id="viewEmployeeName">-</h4>
                            <p class="text-muted mb-1"><i class="bi bi-envelope me-2"></i><span id="viewEmployeeEmail">-</span></p>
                            <p class="text-muted mb-1"><i class="bi bi-person-badge me-2"></i><span id="viewEmployeeRole">-</span></p>
                            <p class="text-muted mb-1"><i class="bi bi-building me-2"></i><span id="viewEmployeeDepartment">-</span></p>
                            <p class="text-muted mb-1"><i class="bi bi-calendar me-2"></i>Joined: <span id="viewEmployeeJoined">-</span></p>
                            <span class="badge bg-success">Active</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="editFromView()">Edit Employee</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Employee ID Card Modal -->
    <div class="modal fade" id="employeeIdCardModal" tabindex="-1" aria-labelledby="employeeIdCardModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="employeeIdCardModalLabel">Employee ID Card</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="id-card">
                        <div class="company-header">
                            <h5>iK soft</h5>
                            <small>Employee ID Card</small>
                        </div>
                        
                        <div class="avatar-circle mx-auto" id="idCardAvatar">
                            A
                        </div>
                        
                        <div class="employee-name mt-3" id="idCardName">-</div>
                        
                        <span class="badge bg-primary employee-role" id="idCardRole">
                            Employee
                        </span>
                        
                        <div class="qr-code-container mx-auto mt-3">
                            <div id="idCardQRCode" class="qrcode"></div>
                        </div>
                        
                        <div class="employee-info mt-3">
                            <p class="mb-1"><strong>ID:</strong> #<span id="idCardId">-</span></p>
                            <p class="mb-1"><strong>Email:</strong> <span id="idCardEmail">-</span></p>
                            <p class="mb-1">
                                <strong>Department:</strong> 
                                <span id="idCardDepartment">-</span>
                            </p>
                            <p class="mb-0"><strong>Joined:</strong> <span id="idCardJoined">-</span></p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="window.printIdCard()">Print ID Card</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Employee Modal -->
    <div class="modal fade" id="deleteEmployeeModal" tabindex="-1" aria-labelledby="deleteEmployeeModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteEmployeeModalLabel">Delete Employee</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the employee <strong id="deleteEmployeeName"></strong>?</p>
                    <p class="text-muted">This action cannot be undone. All employee data will be permanently removed.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form id="deleteEmployeeForm" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete Employee</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
        // Ensure Bootstrap is loaded before executing
        document.addEventListener('DOMContentLoaded', function() {
            // Mobile sidebar toggle
            const sidebarToggle = document.getElementById('sidebarToggle');
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', function() {
                    sidebar.classList.toggle('show');
                    overlay.classList.toggle('show');
                });
            }
            
            // Close sidebar when overlay is clicked
            if (overlay) {
                overlay.addEventListener('click', function() {
                    sidebar.classList.remove('show');
                    overlay.classList.remove('show');
                });
            }
            
            // Tab navigation handling
            const tabTriggerList = [].slice.call(document.querySelectorAll('#employeeTabs button'))
            tabTriggerList.forEach(function (tabTrigger) {
                tabTrigger.addEventListener('click', function (event) {
                    event.preventDefault();
                    const tabTriggerEl = event.target;
                    const tabPaneId = tabTriggerEl.getAttribute('data-bs-target');
                    
                    // Remove active class from all tabs and panes
                    document.querySelectorAll('#employeeTabs button').forEach(function(tab) {
                        tab.classList.remove('active');
                    });
                    document.querySelectorAll('.tab-pane').forEach(function(pane) {
                        pane.classList.remove('show', 'active');
                    });
                    
                    // Add active class to clicked tab
                    tabTriggerEl.classList.add('active');
                    
                    // Show the corresponding pane
                    const tabPane = document.querySelector(tabPaneId);
                    if (tabPane) {
                        tabPane.classList.add('show', 'active');
                    }
                });
            });
            
            // Search functionality for each tab
            document.getElementById('searchEmployees').addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const tableRows = document.querySelectorAll('#all-employees tbody tr');
                
                tableRows.forEach(row => {
                    const name = row.querySelector('h6').textContent.toLowerCase();
                    const email = row.cells[1].textContent.toLowerCase();
                    const role = row.cells[2].textContent.toLowerCase();
                    
                    if (name.includes(searchTerm) || email.includes(searchTerm) || role.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            document.getElementById('searchManagers').addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const tableRows = document.querySelectorAll('#managers tbody tr');
                
                tableRows.forEach(row => {
                    const name = row.querySelector('h6').textContent.toLowerCase();
                    const email = row.cells[1].textContent.toLowerCase();
                    
                    if (name.includes(searchTerm) || email.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            document.getElementById('searchStaff').addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const tableRows = document.querySelectorAll('#staff tbody tr');
                
                tableRows.forEach(row => {
                    const name = row.querySelector('h6').textContent.toLowerCase();
                    const email = row.cells[1].textContent.toLowerCase();
                    
                    if (name.includes(searchTerm) || email.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });

            document.getElementById('searchNewEmployees').addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const tableRows = document.querySelectorAll('#new-employees tbody tr');
                
                tableRows.forEach(row => {
                    const name = row.querySelector('h6').textContent.toLowerCase();
                    const email = row.cells[1].textContent.toLowerCase();
                    const role = row.cells[2].textContent.toLowerCase();
                    
                    if (name.includes(searchTerm) || email.includes(searchTerm) || role.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
            
            // View Employee Function
            window.viewEmployee = function(id, name, email, role, joined, departmentName, departmentId) {
                document.getElementById('viewEmployeeName').textContent = name;
                document.getElementById('viewEmployeeEmail').textContent = email;
                document.getElementById('viewEmployeeRole').textContent = role.charAt(0).toUpperCase() + role.slice(1);
                document.getElementById('viewEmployeeDepartment').textContent = departmentName || 'No Department';
                document.getElementById('viewEmployeeJoined').textContent = joined;
                document.getElementById('viewEmployeeAvatar').textContent = name.charAt(0).toUpperCase();
                
                // Store ID and department ID for edit function
                document.getElementById('viewEmployeeModal').setAttribute('data-employee-id', id);
                document.getElementById('viewEmployeeModal').setAttribute('data-department-id', departmentId);
                
                var viewModal = new bootstrap.Modal(document.getElementById('viewEmployeeModal'));
                viewModal.show();
            }

            // Show Employee ID Card Function
            window.showEmployeeIdCard = function(id, name, email, role, joined, departmentName, departmentId) {
                // Set employee data in the ID card
                document.getElementById('idCardName').textContent = name;
                document.getElementById('idCardEmail').textContent = email;
                document.getElementById('idCardRole').textContent = role.charAt(0).toUpperCase() + role.slice(1);
                document.getElementById('idCardRole').className = 'badge bg-' + (role === 'manager' ? 'primary' : 'secondary') + ' employee-role';
                document.getElementById('idCardDepartment').textContent = departmentName || 'No Department';
                document.getElementById('idCardJoined').textContent = joined;
                document.getElementById('idCardId').textContent = id;
                document.getElementById('idCardAvatar').textContent = name.charAt(0).toUpperCase();
                
                // Clear previous QR code
                document.getElementById('idCardQRCode').innerHTML = '';
                
                // Generate QR code
                try {
                    new QRCode(document.getElementById('idCardQRCode'), {
                        text: "Employee ID: " + id + "\nName: " + name + "\nEmail: " + email + "\nRole: " + role.charAt(0).toUpperCase() + role.slice(1) + "\nDepartment: " + (departmentName || 'No Department'),
                        width: 128,
                        height: 128,
                        colorDark: "#000000",
                        colorLight: "#ffffff",
                        correctLevel: QRCode.CorrectLevel.H
                    });
                } catch (e) {
                    console.error("Failed to generate QR code:", e);
                    document.getElementById('idCardQRCode').innerHTML = "<div class='text-center p-3'><small>QR Code: " + id + "</small></div>";
                }
                
                // Show the ID card modal
                var idCardModal = new bootstrap.Modal(document.getElementById('employeeIdCardModal'));
                idCardModal.show();
            }

            // Print ID Card Function
            window.printIdCard = function() {
                var printContents = document.querySelector('#employeeIdCardModal .modal-body').innerHTML;
                var originalContents = document.body.innerHTML;
                
                document.body.innerHTML = '<div class="container">' + printContents + '</div>';
                window.print();
                document.body.innerHTML = originalContents;
                location.reload();
            }

            // Edit from View Modal
            window.editFromView = function() {
                const viewModal = bootstrap.Modal.getInstance(document.getElementById('viewEmployeeModal'));
                const employeeId = document.getElementById('viewEmployeeModal').getAttribute('data-employee-id');
                const departmentId = document.getElementById('viewEmployeeModal').getAttribute('data-department-id');
                const name = document.getElementById('viewEmployeeName').textContent;
                const email = document.getElementById('viewEmployeeEmail').textContent;
                const role = document.getElementById('viewEmployeeRole').textContent.toLowerCase();
                
                viewModal.hide();
                
                setTimeout(() => {
                    window.location.href = '/superadmin/employees/' + employeeId + '/edit';
                }, 300);
            }

            // Delete Employee Function
            window.deleteEmployee = function(id, name) {
                console.log('Delete Employee called with ID:', id);
                document.getElementById('deleteEmployeeName').textContent = name;
                const actionUrl = '<?php echo e(url("superadmin/employees")); ?>/' + id;
                console.log('Setting delete form action to:', actionUrl);
                document.getElementById('deleteEmployeeForm').action = actionUrl;
                
                var deleteModal = new bootstrap.Modal(document.getElementById('deleteEmployeeModal'));
                deleteModal.show();
            }

            // Success/Error Messages Auto-hide
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                if (!alert.classList.contains('alert-permanent')) {
                    setTimeout(function() {
                        alert.style.transition = 'opacity 0.5s';
                        alert.style.opacity = '0';
                        setTimeout(function() {
                            alert.remove();
                        }, 500);
                    }, 5000);
                }
            });

            // Modal Focus Management for Better Accessibility
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                modal.addEventListener('show.bs.modal', function () {
                    // Remove aria-hidden when modal is being shown
                    modal.removeAttribute('aria-hidden');
                });
                
                modal.addEventListener('shown.bs.modal', function () {
                    // Ensure aria-hidden is removed and focus on the first focusable element
                    modal.removeAttribute('aria-hidden');
                    const firstFocusable = modal.querySelector('input, select, textarea, button:not([data-bs-dismiss])');
                    if (firstFocusable) {
                        firstFocusable.focus();
                    }
                });
                
                modal.addEventListener('hide.bs.modal', function () {
                    // Remove aria-hidden before hiding
                    modal.removeAttribute('aria-hidden');
                });
                
                modal.addEventListener('hidden.bs.modal', function () {
                    // Only add aria-hidden after modal is completely hidden
                    setTimeout(() => {
                        modal.setAttribute('aria-hidden', 'true');
                    }, 100);
                });
            });

            // Override Bootstrap's default modal behavior
            const originalModalShow = bootstrap.Modal.prototype.show;
            bootstrap.Modal.prototype.show = function() {
                // Remove aria-hidden before calling original show
                this._element.removeAttribute('aria-hidden');
                return originalModalShow.call(this);
            };

            const originalModalHide = bootstrap.Modal.prototype.hide;
            bootstrap.Modal.prototype.hide = function() {
                // Remove aria-hidden before hiding
                this._element.removeAttribute('aria-hidden');
                return originalModalHide.call(this);
            };

            // MutationObserver to prevent Bootstrap from adding aria-hidden on visible modals
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    if (mutation.type === 'attributes' && mutation.attributeName === 'aria-hidden') {
                        const target = mutation.target;
                        if (target.classList.contains('modal') && target.style.display === 'block') {
                            // If modal is visible but aria-hidden was added, remove it
                            if (target.getAttribute('aria-hidden') === 'true') {
                                target.removeAttribute('aria-hidden');
                            }
                        }
                    }
                });
            });

            // Observe all modals for attribute changes
            modals.forEach(modal => {
                observer.observe(modal, {
                    attributes: true,
                    attributeFilter: ['aria-hidden', 'style', 'class']
                });
            });
        });
    </script>
</body>
</html><?php /**PATH D:\xampp\htdocs\imteaz\HR-Management\resources\views/dashboards/Admin/employees.blade.php ENDPATH**/ ?>