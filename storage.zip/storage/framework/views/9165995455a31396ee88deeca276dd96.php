<?php $__env->startSection('title', 'Notifications - Manager Dashboard'); ?>
<?php $__env->startSection('page-title', 'Notifications'); ?>
<?php $__env->startSection('page-icon', 'bi bi-bell'); ?>
<?php $__env->startSection('page-description', 'View and manage your notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5><i class="bi bi-bell"></i> Notifications</h5>
                    <div>
                        <button class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-check-all"></i> Mark All Read
                        </button>
                        <button class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-trash"></i> Clear All
                        </button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="notification-list">
                        <?php $__empty_1 = true; $__currentLoopData = $notifications ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="notification-item <?php echo e(!$notification['read'] ? 'unread' : ''); ?> p-3 border-bottom">
                            <div class="d-flex align-items-start">
                                <div class="notification-icon me-3">
                                    <?php switch($notification['type']):
                                        case ('attendance'): ?>
                                            <i class="bi bi-person-check text-success fs-4"></i>
                                            <?php break; ?>
                                        <?php case ('leave_request'): ?>
                                            <i class="bi bi-calendar-event text-info fs-4"></i>
                                            <?php break; ?>
                                        <?php case ('task'): ?>
                                            <i class="bi bi-check-circle text-warning fs-4"></i>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <i class="bi bi-bell text-primary fs-4"></i>
                                    <?php endswitch; ?>
                                </div>
                                <div class="notification-content flex-grow-1">
                                    <div class="notification-message">
                                        <?php echo e($notification['message']); ?>

                                    </div>
                                    <div class="notification-time text-muted small">
                                        <i class="bi bi-clock"></i> <?php echo e($notification['time']); ?>

                                    </div>
                                </div>
                                <div class="notification-actions">
                                    <?php if(!$notification['read']): ?>
                                        <span class="badge bg-primary">New</span>
                                    <?php endif; ?>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                            <i class="bi bi-three-dots"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="#"><i class="bi bi-check"></i> Mark as Read</a></li>
                                            <li><a class="dropdown-item" href="#"><i class="bi bi-trash"></i> Delete</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-5">
                            <i class="bi bi-bell-slash fs-1 text-muted"></i>
                            <p class="text-muted mt-3">No notifications found</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('styles'); ?>
<style>
.notification-item {
    transition: all 0.3s ease;
}

.notification-item:hover {
    background-color: #f8f9fa;
    transform: translateX(5px);
}

.notification-item.unread {
    background-color: #fff3cd;
    border-left: 4px solid #ffc107;
}

.notification-icon {
    min-width: 50px;
    text-align: center;
}

.notification-list {
    max-height: 600px;
    overflow-y: auto;
}

.notification-list::-webkit-scrollbar {
    width: 6px;
}

.notification-list::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.notification-list::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 10px;
}

.notification-list::-webkit-scrollbar-thumb:hover {
    background: #555;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\imteaz\HR-Management\resources\views/manager/notifications.blade.php ENDPATH**/ ?>