<?php $__env->startSection('title', 'Team Messages - Manager Dashboard'); ?>
<?php $__env->startSection('page-title', 'Team Messages'); ?>
<?php $__env->startSection('page-icon', 'bi bi-chat-dots'); ?>
<?php $__env->startSection('page-description', 'Send and manage team communications'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row g-4">
        <!-- Send Message Card -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5><i class="bi bi-send"></i> Send Team Message</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('manager.message')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="priority" class="form-label">Priority</label>
                            <select class="form-select" id="priority" name="priority" required>
                                <option value="low">Low</option>
                                <option value="normal" selected>Normal</option>
                                <option value="high">High</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Recipients</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="all" id="all_team" name="recipients[]" checked>
                                <label class="form-check-label" for="all_team">
                                    All Team Members
                                </label>
                            </div>
                            <small class="text-muted">Message will be sent to all your team members</small>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-send"></i> Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Messages List -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h5><i class="bi bi-inbox"></i> Recent Messages</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th>From/To</th>
                                    <th>Date</th>
                                    <th>Priority</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $messages ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="<?php echo e(!$message['read'] && $message['type'] == 'received' ? 'table-warning' : ''); ?>">
                                    <td>
                                        <strong><?php echo e($message['subject']); ?></strong>
                                        <?php if(!$message['read'] && $message['type'] == 'received'): ?>
                                            <span class="badge bg-primary ms-2">New</span>
                                        <?php endif; ?>
                                        <?php if($message['type'] == 'sent'): ?>
                                            <span class="badge bg-info ms-2">Sent</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($message['from']); ?>

                                        <?php if($message['type'] == 'sent' && isset($message['recipients_count'])): ?>
                                            <small class="text-muted d-block">To <?php echo e($message['recipients_count']); ?> members</small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($message['date']); ?></td>
                                    <td>
                                        <span class="badge 
                                            <?php switch($message['priority']):
                                                case ('high'): ?> bg-danger <?php break; ?>
                                                <?php case ('normal'): ?> bg-primary <?php break; ?>
                                                <?php case ('low'): ?> bg-secondary <?php break; ?>
                                            <?php endswitch; ?>
                                        ">
                                            <?php echo e(ucfirst($message['priority'])); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php if($message['type'] == 'received'): ?>
                                            <span class="badge <?php echo e($message['read'] ? 'bg-success' : 'bg-warning'); ?>">
                                                <?php echo e($message['read'] ? 'Read' : 'Unread'); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Sent</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button class="btn btn-sm btn-outline-primary" title="View Message">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                            <?php if($message['type'] == 'received' && !$message['read']): ?>
                                                <form method="POST" action="<?php echo e(route('manager.messages.mark-read')); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="message_id" value="<?php echo e($message['id']); ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-success" title="Mark as Read">
                                                        <i class="bi bi-check"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            <?php if($message['type'] == 'sent'): ?>
                                                <form method="POST" action="<?php echo e(route('manager.messages.delete', $message['id'])); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete Message" 
                                                            onclick="return confirm('Are you sure you want to delete this message?')">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <i class="bi bi-inbox fs-1 text-muted"></i>
                                        <p class="text-muted mt-2">No messages found</p>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\imteaz\HR-Management\resources\views/manager/messages.blade.php ENDPATH**/ ?>