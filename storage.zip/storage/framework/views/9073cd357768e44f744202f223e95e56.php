<?php $__env->startSection('title', 'My Team - Manager Dashboard'); ?>
<?php $__env->startSection('page-title', 'My Team'); ?>
<?php $__env->startSection('page-icon', 'bi bi-people'); ?>
<?php $__env->startSection('page-description', 'View and manage your team members'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5><i class="bi bi-people"></i> My Team</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Position</th>
                                    <th>Status</th>
                                    <th>Join Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($member['name']); ?></td>
                                    <td><?php echo e($member['email']); ?></td>
                                    <td><?php echo e($member['position']); ?></td>
                                    <td>
                                        <span class="badge bg-success"><?php echo e($member['status']); ?></span>
                                    </td>
                                    <td><?php echo e($member['join_date']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary">
                                            <i class="bi bi-eye"></i> View
                                        </button>
                                        <button class="btn btn-sm btn-warning">
                                            <i class="bi bi-pencil"></i> Edit
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No team members found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\imteaz\HR-Management\resources\views/manager/team.blade.php ENDPATH**/ ?>